
# va-nextjs (clean)

- System theme (no forced dark)
- Apple-like subtle transitions
- Admin overlay (/?admin=1&key=changeme) editing content saved in localStorage
- Logo in header: upload in Admin → Brand (saved as data-URL)
- Real-time updates across tabs via BroadcastChannel/storage events
- Simple on-site chat, persisted per visitor

## Dev
```bash
npm install
npm run dev
```
