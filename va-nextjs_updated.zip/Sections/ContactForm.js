
export default function ContactForm({ content, onSubmitted }){
  const c = content.contact || {};
  return (
    <section id="Contact" className="py-20 reveal">
      <div className="max-w-3xl mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-6">{c.title || 'Contact'}</h2>
        <form onSubmit={(e)=>{ e.preventDefault(); onSubmitted?.(); alert(c.successMessage || 'Thanks!'); }} className="space-y-3">
          <input type="email" placeholder="Your email" required className="w-full p-3 rounded border border-border bg-white dark:bg-neutral-900"/>
          <textarea placeholder="Your message" required className="w-full p-3 rounded border border-border bg-white dark:bg-neutral-900"/>
          <button className="btn btn-primary w-full">{c.cta || 'Send'}</button>
        </form>
      </div>
    </section>
  );
}
