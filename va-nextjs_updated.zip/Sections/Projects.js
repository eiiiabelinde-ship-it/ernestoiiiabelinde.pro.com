
export default function Projects({ content }){
  const cfg = content.projectsConfig || {};
  const items = content.projects || [];
  return (
    <section id="Projects" className="py-20 reveal" style={{
      color: cfg.fontColor || 'inherit',
      backgroundImage: cfg.background ? `url(${cfg.background})` : 'none',
      backgroundSize: 'cover',
      backgroundPosition: 'center',
    }}>
      <div className="max-w-6xl mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-10">Projects</h2>
        <div className="grid md:grid-cols-2 gap-6">
          {items.map((p, i)=>(
            <div key={i} className="card p-6">
              <h3 className="text-xl font-semibold mb-2">{p.title}</h3>
              <p className="opacity-80 mb-4">{p.summary}</p>
              {p.cta && <a href={p.link || '#Projects'} className="btn">{p.cta}</a>}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
