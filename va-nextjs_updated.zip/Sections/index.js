
export { default as Hero } from './Hero';
export { default as About } from './About';
export { default as Services } from './Services';
export { default as Projects } from './Projects';
export { default as ProjectPlan } from './ProjectPlan';
export { default as Terms } from './Terms';
export { default as ContactForm } from './ContactForm';
export { default as Footer } from './Footer';
export { default as News } from './News';
export { default as Newsletter } from './Newsletter';
export { default as Support } from './Support';
