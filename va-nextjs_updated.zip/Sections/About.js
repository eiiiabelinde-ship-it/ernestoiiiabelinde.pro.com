
export default function About({ content }){
  const c = content.about || {};
  return (
    <section id="About" className="py-20 reveal" style={{
      color: c.fontColor || 'inherit',
      backgroundImage: c.background ? `url(${c.background})` : 'none',
      backgroundSize: 'cover',
      backgroundPosition: 'center',
    }}>
      <div className="max-w-4xl mx-auto px-4 text-center">
        <h2 className="text-3xl font-bold mb-4">About</h2>
        <p className="text-lg leading-relaxed opacity-90">{c.body}</p>
      </div>
    </section>
  );
}
