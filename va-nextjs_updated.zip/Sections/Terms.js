
export default function Terms({ content }){
  const c = content.terms || {};
  return (
    <section id="Terms" className="py-20 reveal">
      <div className="max-w-4xl mx-auto px-4">
        <h2 className="text-3xl font-bold mb-4">{c.title || 'Terms'}</h2>
        <p className="whitespace-pre-line opacity-90">{c.body}</p>
      </div>
    </section>
  );
}
