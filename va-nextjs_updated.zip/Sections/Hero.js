
export default function Hero({ content }){
  const c = content.hero || {};
  const link = c.ctaLink || 'https://calendly.com/eiiiabelinde/let-s-make-it-happen-book-your-appointment-today';
  return (
    <section id="Home" className="relative pt-28 pb-24 text-center reveal"
      style={{
        color: c.fontColor || 'inherit',
        backgroundImage: c.background ? `url(${c.background})` : 'none',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
      }}
    >
      <div className="max-w-3xl mx-auto px-4">
        <h1 className="text-5xl font-semibold tracking-tight mb-4">{c.headline}</h1>
        <p className="text-lg opacity-80 mb-6">{c.sub}</p>
        {c.cta && <a href={link} target="_blank" rel="noreferrer" className="btn btn-primary">{c.cta}</a>}
      </div>
    </section>
  );
}
