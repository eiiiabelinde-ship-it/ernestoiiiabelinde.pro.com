
import ChatWidget from '../components/ChatWidget';

export default function Support({ content, threadId }){
  return (
    <section id="Support" className="py-20 reveal">
      <div className="max-w-3xl mx-auto px-4 text-center">
        <h2 className="text-3xl font-bold mb-3">Support</h2>
        <p className="opacity-80 mb-6">Need help? Send us a message and we'll reply here.</p>
      </div>
      {/* Dedicated chat instance on support page */}
      <div className="max-w-3xl mx-auto px-4">
        <div className="card p-4">
          <ChatWidget threadId={threadId} />
        </div>
      </div>
    </section>
  );
}
