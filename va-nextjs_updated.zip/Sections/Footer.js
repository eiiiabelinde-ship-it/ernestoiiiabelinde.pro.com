
export default function Footer({ content }){
  const email = content?.contact?.email || 'hello@example.com';
  const links = content?.footer?.links || [];
  const socials = content?.footer?.socials || [];
  return (
    <footer className="py-12 border-t border-border">
      <div className="max-w-7xl mx-auto px-4 md:px-6 grid md:grid-cols-3 gap-6 text-sm items-center">
        <div>© {new Date().getFullYear()} {content?.brand?.name || 'Brand'}</div>
        <div className="flex items-center justify-center gap-4">
          {links.map((l, i)=>(<a key={i} href={l.href} className="link">{l.label}</a>))}
        </div>
        <div className="flex items-center justify-end gap-4">
          <a href={`mailto:${email}`} className="link">{email}</a>
          {socials.map((s, i)=>(<a key={i} href={s.href} className="link">{s.label}</a>))}
        </div>
      </div>
    </footer>
  );
}
