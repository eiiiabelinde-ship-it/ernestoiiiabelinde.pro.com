
export default function News({ content }){
  const news = content.news || { items: [] };
  return (
    <section id="News" className="py-20 reveal">
      <div className="max-w-5xl mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-8">{news.title || 'Elevated News'}</h2>
        <div className="space-y-4">
          {(news.items||[]).map((n,i)=>(
            <a key={i} href={n.link || '#'} className="card p-4 block">
              <div className="flex items-center justify-between">
                <div className="font-medium">{n.title}</div>
                <div className="text-sm opacity-70">{n.date}</div>
              </div>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}
