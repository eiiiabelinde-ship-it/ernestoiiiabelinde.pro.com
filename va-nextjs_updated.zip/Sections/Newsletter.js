
export default function Newsletter({ content }){
  const n = content.newsletter || {};
  const onSubmit = (e)=>{
    e.preventDefault();
    alert(n.success || 'Thanks!');
  };
  return (
    <section id="Newsletter" className="py-20 reveal">
      <div className="max-w-3xl mx-auto px-4 text-center">
        <h2 className="text-3xl font-bold mb-3">{n.title || 'Newsletter'}</h2>
        <p className="opacity-80 mb-6">{n.sub}</p>
        <form onSubmit={onSubmit} className="flex gap-2 max-w-md mx-auto">
          <input type="email" required placeholder={n.placeholder || 'you@company.com'} className="flex-1 rounded border border-border p-3 bg-white dark:bg-neutral-900"/>
          <button className="btn btn-primary">{n.cta || 'Subscribe'}</button>
        </form>
      </div>
    </section>
  );
}
