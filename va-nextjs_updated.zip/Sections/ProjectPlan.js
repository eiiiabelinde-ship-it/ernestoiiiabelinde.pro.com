
export default function ProjectPlan({ content }){
  const plan = content.plan || { boards: [] };
  return (
    <section id="Project-Plan" className="py-20 reveal">
      <div className="max-w-6xl mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-2">{plan.title || 'Project Plan'}</h2>
        <p className="text-center opacity-80 mb-8">{plan.sub}</p>
        <div className="grid md:grid-cols-3 gap-4">
          {(plan.boards||[]).map((b, i)=>(
            <div key={i} className="card p-4">
              <div className="font-semibold mb-3">{b.name}</div>
              <div className="space-y-3">
                {(b.items||[]).map((it, j)=>(
                  <div key={j} className="rounded-lg border border-border p-3 text-sm">
                    <div className="font-medium">{it.task}</div>
                    <div className="flex items-center justify-between opacity-80">
                      <span>{it.owner}</span>
                      <span>{it.status} • {it.eta}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
