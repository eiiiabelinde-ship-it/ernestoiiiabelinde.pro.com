
export default function Services({ content }){
  const cfg = content.servicesConfig || {};
  const items = content.services || [];
  return (
    <section id="Services" className="py-20 reveal" style={{
      color: cfg.fontColor || 'inherit',
      backgroundImage: cfg.background ? `url(${cfg.background})` : 'none',
      backgroundSize: 'cover',
      backgroundPosition: 'center',
    }}>
      <div className="max-w-6xl mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-10">Services</h2>
        <div className="grid md:grid-cols-3 gap-6">
          {items.map((s, i)=>(
            <div key={i} className={`card p-6 ${s.popular? 'ring-2 ring-[var(--accent)]':''}`}>
              <div className="flex items-baseline justify-between mb-2">
                <h3 className="text-xl font-semibold">{s.name}</h3>
                <div className="text-2xl font-bold">${s.price}<span className="text-sm font-normal opacity-70">{s.period}</span></div>
              </div>
              <ul className="text-sm space-y-2 mb-4 opacity-90">
                {(s.features||[]).map((f, j)=>(<li key={j}>• {f}</li>))}
              </ul>
              {s.cta && <a href={s.ctaLink || '#Contact'} className="btn btn-primary w-full">{s.cta}</a>}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
