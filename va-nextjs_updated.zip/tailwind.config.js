
/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: 'media',
  content: [
    "./pages/**/*.{js,jsx,ts,tsx}",
    "./components/**/*.{js,jsx,ts,tsx}",
    "./Sections/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        accent: "var(--accent)",
        muted: "var(--muted)",
        border: "var(--border)",
        fg: "var(--fg)",
        bg: "var(--bg)",
      },
      boxShadow: {
        card: "0 10px 30px rgba(0,0,0,.08)",
      }
    },
  },
  plugins: [],
}
