
import { useEffect, useMemo, useState } from 'react';
import { defaultContent } from '../hooks/useLiveContent';
import { listChatThreads, appendChat, getChat } from '../lib/storage';

export default function AdminPanel({ content, setContent }){
  const [local, setLocal] = useState(content);
  const [tab, setTab] = useState('Content');
  const [selectedThread, setSelectedThread] = useState(null);
  const [reply, setReply] = useState('');

  useEffect(()=> setLocal(content), [content]);

  const updatePath = (path, value)=>{
    setLocal(prev=>{
      const clone = structuredClone(prev);
      const keys = path.split('.');
      let obj = clone;
      for (let i = 0; i < keys.length-1; i++) {
        if (!obj[keys[i]]) obj[keys[i]] = {};
        obj[keys[i]] = { ...obj[keys[i]] };
        obj = obj[keys[i]];
      }
      obj[keys[keys.length-1]] = value;
      return clone;
    });
  };

  const onFile = (path, file)=>{
    const clear = !file;
    if (clear){ updatePath(path, ''); return; }
    const reader = new FileReader();
    reader.onload = ()=> updatePath(path, reader.result);
    reader.readAsDataURL(file);
  };

  const addService = ()=> setLocal(prev=>({ ...prev, services:[...prev.services, { name:'New', price:0, period:'/mo', features:['Feature'], cta:'Select', ctaLink:'#Contact', popular:false }] }));
  const addProject = ()=> setLocal(prev=>({ ...prev, projects:[...prev.projects, { title:'New Project', summary:'Summary', cta:'View', link:'#' }] }));
  const addNews = ()=> setLocal(prev=>({ ...prev, news:{ ...(prev.news||{}), items:[...((prev.news&&prev.news.items)||[]), { title:'Update', date:new Date().toISOString().slice(0,10), link:'#' }] } }));
  const addNav = ()=> setLocal(prev=>({ ...prev, nav:{ links:[...(prev.nav?.links||[]), { id: 'Custom-'+(prev.nav?.links?.length||0), label:'New', href:'#' }] } }));

  const save = ()=> setContent(local);
  const resetSection = (key)=> setLocal(prev=>({ ...prev, [key]: structuredClone(defaultContent[key]) }));
  const resetAll = ()=> setLocal(structuredClone(defaultContent));

  // Messages
  const threads = useMemo(()=> (typeof window==='undefined'? [] : listChatThreads()), [local]);
  const messages = useMemo(()=> selectedThread ? (getChat(selectedThread)||[]) : [], [selectedThread, local]);

  const sendReply = (e)=>{
    e.preventDefault();
    if (!selectedThread || !reply.trim()) return;
    appendChat(selectedThread, { role:'admin', text: reply.trim(), ts: Date.now() });
    setReply('');
  };

  return (
    <div className="fixed top-0 right-0 w-[480px] h-screen bg-black/90 text-white p-6 overflow-y-auto z-50">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-bold">Admin Panel</h2>
        <div className="flex gap-2">
          <button onClick={resetAll} className="text-xs px-2 py-1 border border-white/30 rounded">Reset All</button>
          <button onClick={save} className="text-xs px-3 py-1 bg-white text-black rounded">Save</button>
        </div>
      </div>

      <div className="flex gap-2 mb-4">
        {['Content','Messages'].map(t=>(
          <button key={t} onClick={()=>setTab(t)} className={`px-3 py-1 rounded ${tab===t?'bg-white text-black':'border border-white/30'}`}>{t}</button>
        ))}
      </div>

      {tab==='Content' && (
        <>
          {/* BRAND */}
          <section className="mb-8">
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-semibold">Brand</h3>
              <button onClick={()=>resetSection('brand')} className="text-xs underline">Reset</button>
            </div>
            <input className="w-full mb-2 p-2 text-black rounded"
              value={local.brand?.name || ''}
              onChange={e=>updatePath('brand.name', e.target.value)}
              placeholder="Brand name"
            />
            <label className="text-xs opacity-80">Accent color</label>
            <input type="color" className="w-full h-10 mb-2"
              value={local.brand?.colors?.primary || '#0a84ff'}
              onChange={e=>updatePath('brand.colors.primary', e.target.value)}
            />
            <label className="text-xs opacity-80">Logo (PNG/SVG)</label>
            <input type="file" accept="image/*" className="w-full mb-2" onChange={e=>onFile('brand.logo', e.target.files?.[0] || null)} />
            {local.brand?.logo && (
              <div className="flex items-center gap-2 mb-2">
                <img src={local.brand.logo} className="w-24 h-16 object-contain bg-white/10 rounded" alt="logo" />
                <button onClick={()=>updatePath('brand.logo', '')} className="text-xs underline">Remove</button>
              </div>
            )}
          </section>

          {/* NAV */}
          <section className="mb-8">
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-semibold">Header Navigation</h3>
              <button onClick={()=>resetSection('nav')} className="text-xs underline">Reset</button>
            </div>
            {(local.nav?.links||[]).map((l,i)=>(
              <div key={i} className="mb-2 p-2 rounded border border-white/20 grid grid-cols-5 gap-2 items-center">
                <input className="col-span-2 p-2 text-black rounded" value={l.label} onChange={e=>{
                  const arr=[...local.nav.links]; arr[i]={...arr[i], label:e.target.value}; setLocal({...local, nav:{links:arr}});
                }} placeholder="Label"/>
                <input className="col-span-3 p-2 text-black rounded" value={l.href} onChange={e=>{
                  const arr=[...local.nav.links]; arr[i]={...arr[i], href:e.target.value}; setLocal({...local, nav:{links:arr}});
                }} placeholder="#About or /support"/>
              </div>
            ))}
            <div className="flex gap-2">
              <button onClick={addNav} className="text-xs px-2 py-1 border border-white/30 rounded">+ Add link</button>
            </div>
          </section>

          {/* HERO */}
          <section className="mb-8">
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-semibold">Hero</h3>
              <button onClick={()=>setLocal(prev=>({ ...prev, hero: structuredClone(defaultContent.hero) }))} className="text-xs underline">Reset</button>
            </div>
            <input className="w-full mb-2 p-2 text-black rounded" value={local.hero?.headline || ''} onChange={e=>updatePath('hero.headline', e.target.value)} placeholder="Headline"/>
            <input className="w-full mb-2 p-2 text-black rounded" value={local.hero?.sub || ''} onChange={e=>updatePath('hero.sub', e.target.value)} placeholder="Subheadline"/>
            <div className="grid grid-cols-2 gap-2">
              <input className="w-full mb-2 p-2 text-black rounded" value={local.hero?.cta || ''} onChange={e=>updatePath('hero.cta', e.target.value)} placeholder="CTA"/>
              <input className="w-full mb-2 p-2 text-black rounded" value={local.hero?.ctaLink || ''} onChange={e=>updatePath('hero.ctaLink', e.target.value)} placeholder="CTA Link"/>
            </div>
            <label className="text-xs opacity-80">Hero text color</label>
            <input type="color" className="w-full h-10 mb-2" value={local.hero?.fontColor || '#ffffff'} onChange={e=>updatePath('hero.fontColor', e.target.value)}/>
            <label className="text-xs opacity-80">Background image</label>
            <input type="file" accept="image/*" className="w-full mb-2" onChange={e=>onFile('hero.background', e.target.files?.[0] || null)} />
            {local.hero?.background && <img src={local.hero.background} className="w-full h-24 object-cover rounded" alt="hero bg" />}
          </section>

          {/* ABOUT */}
          <section className="mb-8">
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-semibold">About</h3>
              <button onClick={()=>setLocal(prev=>({ ...prev, about: structuredClone(defaultContent.about) }))} className="text-xs underline">Reset</button>
            </div>
            <textarea className="w-full mb-2 p-2 text-black rounded" value={local.about?.body || ''} onChange={e=>updatePath('about.body', e.target.value)} placeholder="About text" rows={4}/>
            <label className="text-xs opacity-80">Text color</label>
            <input type="color" className="w-full h-10 mb-2" value={local.about?.fontColor || '#ffffff'} onChange={e=>updatePath('about.fontColor', e.target.value)}/>
            <label className="text-xs opacity-80">Background image</label>
            <input type="file" accept="image/*" className="w-full mb-2" onChange={e=>onFile('about.background', e.target.files?.[0] || null)} />
            {local.about?.background && <img src={local.about.background} className="w-full h-24 object-cover rounded" alt="about bg" />}
          </section>

          {/* SERVICES */}
          <section className="mb-8">
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-semibold">Services</h3>
              <div className="flex items-center gap-2">
                <button onClick={()=>setLocal(prev=>({ ...prev, servicesConfig: structuredClone(defaultContent.servicesConfig), services: structuredClone(defaultContent.services) }))} className="text-xs underline">Reset</button>
                <button onClick={addService} className="text-xs px-2 py-1 border border-white/30 rounded">+ Add</button>
              </div>
            </div>
            <label className="text-xs opacity-80">Background image</label>
            <input type="file" accept="image/*" className="w-full mb-2" onChange={e=>onFile('servicesConfig.background', e.target.files?.[0] || null)} />
            {(local.services||[]).map((s, i)=>(
              <div key={i} className="mb-3 p-2 rounded border border-white/20">
                <div className="grid grid-cols-2 gap-2">
                  <input className="w-full mb-2 p-2 text-black rounded" value={s.name} onChange={e=>{ const arr=[...local.services]; arr[i].name = e.target.value; setLocal({...local, services: arr});}} placeholder="Name"/>
                  <input className="w-full mb-2 p-2 text-black rounded" value={s.cta} onChange={e=>{ const arr=[...local.services]; arr[i].cta = e.target.value; setLocal({...local, services: arr});}} placeholder="CTA"/>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <input type="number" className="w-full mb-2 p-2 text-black rounded" value={s.price} onChange={e=>{ const arr=[...local.services]; arr[i].price = parseInt(e.target.value||0); setLocal({...local, services: arr});}} placeholder="Price"/>
                  <input className="w-full mb-2 p-2 text-black rounded" value={s.period} onChange={e=>{ const arr=[...local.services]; arr[i].period = e.target.value; setLocal({...local, services: arr});}} placeholder="/mo"/>
                </div>
                <input className="w-full mb-2 p-2 text-black rounded" value={s.ctaLink || ''} onChange={e=>{ const arr=[...local.services]; arr[i].ctaLink = e.target.value; setLocal({...local, services: arr});}} placeholder="CTA Link"/>
                <textarea className="w-full mb-2 p-2 text-black rounded" value={(s.features||[]).join('\n')} onChange={e=>{ const arr=[...local.services]; arr[i].features = e.target.value.split(/\n|,/).map(t=>t.trim()).filter(Boolean); setLocal({...local, services: arr});}} placeholder="Features (one per line)"/>
                <label className="text-xs opacity-80">Popular?</label>
                <input type="checkbox" className="ml-2" checked={!!s.popular} onChange={e=>{ const arr=[...local.services]; arr[i].popular = e.target.checked; setLocal({...local, services: arr});}}/>
              </div>
            ))}
          </section>

          {/* PROJECTS */}
          <section className="mb-8">
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-semibold">Projects</h3>
              <div className="flex items-center gap-2">
                <button onClick={()=>setLocal(prev=>({ ...prev, projectsConfig: structuredClone(defaultContent.projectsConfig), projects: structuredClone(defaultContent.projects) }))} className="text-xs underline">Reset</button>
                <button onClick={addProject} className="text-xs px-2 py-1 border border-white/30 rounded">+ Add</button>
              </div>
            </div>
            <label className="text-xs opacity-80">Background image</label>
            <input type="file" accept="image/*" className="w-full mb-2" onChange={e=>onFile('projectsConfig.background', e.target.files?.[0] || null)} />
            {(local.projects||[]).map((p, i)=>(
              <div key={i} className="mb-3 p-2 rounded border border-white/20">
                <input className="w-full mb-2 p-2 text-black rounded" value={p.title} onChange={e=>{ const arr=[...local.projects]; arr[i].title = e.target.value; setLocal({...local, projects: arr});}} placeholder="Title"/>
                <textarea className="w-full mb-2 p-2 text-black rounded" value={p.summary} onChange={e=>{ const arr=[...local.projects]; arr[i].summary = e.target.value; setLocal({...local, projects: arr});}} placeholder="Summary"/>
                <div className="grid grid-cols-2 gap-2">
                  <input className="w-full mb-2 p-2 text-black rounded" value={p.cta || ''} onChange={e=>{ const arr=[...local.projects]; arr[i].cta = e.target.value; setLocal({...local, projects: arr});}} placeholder="CTA"/>
                  <input className="w-full mb-2 p-2 text-black rounded" value={p.link || ''} onChange={e=>{ const arr=[...local.projects]; arr[i].link = e.target.value; setLocal({...local, projects: arr});}} placeholder="Link"/>
                </div>
              </div>
            ))}
          </section>

          {/* PLAN */}
          <section className="mb-8">
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-semibold">Project Plan</h3>
              <button onClick={()=>setLocal(prev=>({ ...prev, plan: structuredClone(defaultContent.plan) }))} className="text-xs underline">Reset</button>
            </div>
            <input className="w-full mb-2 p-2 text-black rounded" value={local.plan?.title || ''} onChange={e=>updatePath('plan.title', e.target.value)} placeholder="Title"/>
            <input className="w-full mb-2 p-2 text-black rounded" value={local.plan?.sub || ''} onChange={e=>updatePath('plan.sub', e.target.value)} placeholder="Subtitle"/>
          </section>

          {/* NEWS */}
          <section className="mb-8">
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-semibold">Elevated News</h3>
              <div className="flex items-center gap-2">
                <button onClick={()=>setLocal(prev=>({ ...prev, news: structuredClone(defaultContent.news) }))} className="text-xs underline">Reset</button>
                <button onClick={addNews} className="text-xs px-2 py-1 border border-white/30 rounded">+ Add</button>
              </div>
            </div>
            {(local.news?.items||[]).map((n,i)=>(
              <div key={i} className="mb-2 grid grid-cols-5 gap-2">
                <input className="col-span-3 p-2 text-black rounded" value={n.title} onChange={e=>{ const arr=[...local.news.items]; arr[i].title=e.target.value; setLocal({...local, news:{...local.news, items:arr}}); }} placeholder="Title"/>
                <input className="p-2 text-black rounded" value={n.date||''} onChange={e=>{ const arr=[...local.news.items]; arr[i].date=e.target.value; setLocal({...local, news:{...local.news, items:arr}}); }} placeholder="YYYY-MM-DD"/>
                <input className="p-2 text-black rounded" value={n.link||''} onChange={e=>{ const arr=[...local.news.items]; arr[i].link=e.target.value; setLocal({...local, news:{...local.news, items:arr}}); }} placeholder="Link"/>
              </div>
            ))}
          </section>

          {/* NEWSLETTER */}
          <section className="mb-8">
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-semibold">Newsletter</h3>
              <button onClick={()=>setLocal(prev=>({ ...prev, newsletter: structuredClone(defaultContent.newsletter) }))} className="text-xs underline">Reset</button>
            </div>
            <input className="w-full mb-2 p-2 text-black rounded" value={local.newsletter?.title || ''} onChange={e=>updatePath('newsletter.title', e.target.value)} placeholder="Title"/>
            <input className="w-full mb-2 p-2 text-black rounded" value={local.newsletter?.sub || ''} onChange={e=>updatePath('newsletter.sub', e.target.value)} placeholder="Subtitle"/>
            <div className="grid grid-cols-2 gap-2">
              <input className="w-full mb-2 p-2 text-black rounded" value={local.newsletter?.placeholder || ''} onChange={e=>updatePath('newsletter.placeholder', e.target.value)} placeholder="Placeholder"/>
              <input className="w-full mb-2 p-2 text-black rounded" value={local.newsletter?.cta || ''} onChange={e=>updatePath('newsletter.cta', e.target.value)} placeholder="CTA"/>
            </div>
            <input className="w-full mb-2 p-2 text-black rounded" value={local.newsletter?.success || ''} onChange={e=>updatePath('newsletter.success', e.target.value)} placeholder="Success message"/>
          </section>

          {/* TERMS */}
          <section className="mb-8">
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-semibold">Terms</h3>
              <button onClick={()=>setLocal(prev=>({ ...prev, terms: structuredClone(defaultContent.terms) }))} className="text-xs underline">Reset</button>
            </div>
            <input className="w-full mb-2 p-2 text-black rounded" value={local.terms?.title || ''} onChange={e=>updatePath('terms.title', e.target.value)} placeholder="Title"/>
            <textarea className="w-full mb-2 p-2 text-black rounded" rows={5} value={local.terms?.body || ''} onChange={e=>updatePath('terms.body', e.target.value)} placeholder="Terms body"/>
          </section>

          {/* CONTACT */}
          <section className="mb-8">
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-semibold">Contact</h3>
              <button onClick={()=>setLocal(prev=>({ ...prev, contact: structuredClone(defaultContent.contact) }))} className="text-xs underline">Reset</button>
            </div>
            <input className="w-full mb-2 p-2 text-black rounded" value={local.contact?.email || ''} onChange={e=>updatePath('contact.email', e.target.value)} placeholder="Email"/>
            <input className="w-full mb-2 p-2 text-black rounded" value={local.contact?.cta || ''} onChange={e=>updatePath('contact.cta', e.target.value)} placeholder="CTA Button"/>
            <input className="w-full mb-2 p-2 text-black rounded" value={local.contact?.successMessage || ''} onChange={e=>updatePath('contact.successMessage', e.target.value)} placeholder="Success message"/>
          </section>
        </>
      )}

      {tab==='Messages' && (
        <section>
          <div className="mb-3">
            <div className="font-semibold mb-2">Threads</div>
            <div className="flex flex-wrap gap-2">
              {(threads||[]).map(t=>(
                <button key={t} onClick={()=>setSelectedThread(t)} className={`px-2 py-1 rounded text-xs border border-white/30 ${selectedThread===t?'bg-white text-black':''}`}>{t}</button>
              ))}
            </div>
          </div>
          {selectedThread ? (
            <div className="rounded border border-white/30 p-2">
              <div className="text-sm opacity-80 mb-2">Thread: {selectedThread}</div>
              <div className="max-h-64 overflow-y-auto space-y-2 mb-2">
                {(getChat(selectedThread)||[]).map((m,i)=>(
                  <div key={i} className={`p-2 rounded border border-white/30 ${m.role==='admin'?'ml-auto':''}`}>
                    <div className="text-[10px] opacity-60">{m.role}</div>
                    <div className="text-sm">{m.text}</div>
                  </div>
                ))}
              </div>
              <form onSubmit={sendReply} className="flex gap-2">
                <input value={reply} onChange={e=>setReply(e.target.value)} className="flex-1 p-2 text-black rounded" placeholder="Reply..."/>
                <button className="px-3 py-1 bg-white text-black rounded text-sm">Send</button>
              </form>
            </div>
          ) : (
            <div className="text-sm opacity-70">Select a thread to reply.</div>
          )}
        </section>
      )}
    </div>
  );
}
