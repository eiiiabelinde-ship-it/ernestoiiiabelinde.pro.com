
import Link from 'next/link';
import { useEffect, useState } from 'react';

export default function Nav({ content }){
  const links = content?.nav?.links || [];
  const [scrolled, setScrolled] = useState(false);
  useEffect(()=>{
    const onScroll = ()=> setScrolled(window.scrollY>6);
    onScroll();
    window.addEventListener('scroll', onScroll);
    return ()=> window.removeEventListener('scroll', onScroll);
  },[]);

  return (
    <header className={`fixed top-0 inset-x-0 z-50 ${scrolled? 'nav-blur': ''}`}>
      <nav className="max-w-7xl mx-auto px-4 md:px-6 h-16 flex items-center justify-between">
        <a href="#Home" className="flex items-center gap-2">
          {content?.brand?.logo ? (
            <img src={content.brand.logo} alt="logo" className="h-8 w-auto rounded"/>
          ) : (
            <div className="h-8 w-8 rounded-xl bg-[var(--accent)]" />
          )}
          <span className="font-semibold">{content?.brand?.name || 'Elevate'}</span>
        </a>

        <div className="hidden md:flex items-center gap-6 text-sm">
          {links.map(l=>(
            <a key={l.id} href={l.href} className="link">{l.label}</a>
          ))}
        </div>
      </nav>
    </header>
  );
}
