
import { useEffect, useRef, useState } from 'react';
import { appendChat, getChat, subscribeChat } from '../lib/storage';

/**
 * Minimal chat widget — shares the same threadId between public and admin.
 */
export default function ChatWidget({ threadId, asAdmin=false }){
  const [open, setOpen] = useState(true);
  const [msgs, setMsgs] = useState([]);
  const inputRef = useRef(null);

  useEffect(()=>{
    if (!threadId) return;
    const unsub = subscribeChat(threadId, setMsgs);
    return unsub;
  }, [threadId]);

  const send = (e)=>{
    e.preventDefault();
    const val = inputRef.current?.value?.trim();
    if (!val) return;
    const m = { role: asAdmin? 'admin':'user', text: val, ts: Date.now() };
    appendChat(threadId, m);
    if (inputRef.current) inputRef.current.value = '';
  };

  return (
    <div className="w-full">
      {open && (
        <div className="rounded-2xl border border-border overflow-hidden bg-white/60 dark:bg-white/5">
          <div className="p-3 border-b border-border flex items-center justify-between">
            <div className="font-medium">Messages</div>
            <button className="text-sm link" onClick={()=>setOpen(false)}>Hide</button>
          </div>
          <div className="p-3 h-64 overflow-y-auto space-y-2">
            {msgs.map((m, i)=>(
              <div key={i} className={`p-2 rounded border border-border max-w-[80%] ${m.role==='admin'?'ml-auto':''}`}>
                <div className="text-xs opacity-60 mb-1">{m.role}</div>
                <div>{m.text}</div>
              </div>
            ))}
          </div>
          <form onSubmit={send} className="p-2 border-t border-border flex gap-2">
            <input ref={inputRef} className="flex-1 rounded border border-border p-2 bg-white dark:bg-neutral-900" placeholder="Type a message..."/>
            <button className="btn btn-primary text-sm">Send</button>
          </form>
        </div>
      )}
      {!open && <button onClick={()=>setOpen(true)} className="btn">Open Chat</button>}
    </div>
  );
}
