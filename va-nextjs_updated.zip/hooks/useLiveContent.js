
'use client';
import { useEffect, useState } from 'react';
import { saveContent, loadContent, subscribeContent } from '../lib/storage';

export const defaultContent = {
  adminKey: 'changeme',
  brand: { name: 'Elevate', logo: '/logo.png', colors: { primary: '#0a84ff' } },
  nav: {
    links: [
      { id: 'Home', label: 'Home', href: '#Home' },
      { id: 'About', label: 'About', href: '#About' },
      { id: 'Services', label: 'Services', href: '#Services' },
      { id: 'Projects', label: 'Projects', href: '#Projects' },
      { id: 'ProjectPlan', label: 'Project Plans', href: '#Project-Plan' },
      { id: 'News', label: 'Elevated News', href: '#News' },
      { id: 'Support', label: 'Support', href: '#Support' },
      { id: 'Newsletter', label: 'Newsletter', href: '#Newsletter' },
      { id: 'Terms', label: 'Terms', href: '#Terms' },
      { id: 'Contact', label: 'Contact', href: '#Contact' }
    ]
  },
  hero: {
    headline: 'Elevate What Matters',
    sub: 'Helping leaders rise higher — with systems that return your time.',
    cta: 'Book a Discovery Call',
    ctaLink: 'https://calendly.com/eiiiabelinde/let-s-make-it-happen-book-your-appointment-today',
    background: '',
    fontColor: ''
  },
  about: {
    title: 'About',
    body: 'Elevate builds lean systems that free your team to do their best work. We partner with founders and operators to automate operations and level up delivery.',
    background: '',
    fontColor: ''
  },
  servicesConfig: { background: '', fontColor: '' },
  services: [
    { name:'Starter', price:199, period:'/mo', features:['Weekly ops audit','Email support','2 automations'], cta:'Select', ctaLink:'#Contact', popular:false },
    { name:'Growth', price:499, period:'/mo', features:['Workflow redesign','Priority support','5 automations'], cta:'Choose Plan', ctaLink:'#Contact', popular:true },
    { name:'Scale', price:999, period:'/mo', features:['Onsite workshop','Custom tooling','Unlimited consult'], cta:'Talk to Us', ctaLink:'#Contact', popular:false }
  ],
  projectsConfig: { background: '', fontColor: '' },
  projects: [
    { title:'Ops Dashboard Revamp', summary:'Consolidated KPIs and alerts with automated escalation.', cta:'View', link:'#Projects' },
    { title:'Sales Handoff Flow', summary:'Reduced deal-to-delivery by 38% with a no-code pipeline.', cta:'Read Case', link:'#Projects' }
  ],
  plan: {
    title:'Project Plan',
    sub:'A simple kanban-like overview (Monday.com style)',
    boards:[
      { name:'Backlog', items:[{ task:'Collect requirements', owner:'EA', status:'Queued', eta:'Aug' }]},
      { name:'In Progress', items:[{ task:'Automation POC', owner:'Dev', status:'Doing', eta:'Aug' }]},
      { name:'Done', items:[{ task:'Kickoff', owner:'PM', status:'Done', eta:'Aug' }]}
    ]
  },
  news: {
    title: 'Elevated News',
    items: [
      { title:'Welcome to Elevate', date:'2025-08-01', link:'#' }
    ]
  },
  newsletter: {
    title: 'Newsletter',
    sub: 'Get practical ops tips and launch notes.',
    placeholder: 'you@company.com',
    cta: 'Subscribe',
    success: 'Thanks! Please check your inbox.'
  },
  terms: { title: 'Terms & Conditions', body: 'By using Elevate you agree to our standard terms...' },
  contact: { title:'Contact', email:'hello@example.com', cta:'Send', successMessage:'Thanks! We will reply shortly.' },
  footer: {
    links: [
      { label:'About', href:'#About' },
      { label:'Terms & Conditions', href:'#Terms' },
      { label:'Contact Us', href:'#Contact' },
      { label:'Support', href:'/support' }
    ],
    socials: [
      { label:'Facebook', href:'#' },
      { label:'LinkedIn', href:'#' },
      { label:'X', href:'#' }
    ]
  },
  sectionsOrder: ['Home','About','Services','Projects','ProjectPlan','News','Support','Newsletter','Terms','Contact']
};

export function useLiveContent(){
  const [content, setContent] = useState(defaultContent);

  useEffect(()=>{
    const saved = loadContent();
    if (saved) setContent(prev => ({ ...prev, ...saved }));
    const unsub = subscribeContent(next => setContent(prev => ({ ...prev, ...next })));
    return unsub;
  }, []);

  useEffect(()=>{
    if (typeof document !== 'undefined') {
      document.documentElement.style.setProperty('--accent', content.brand?.colors?.primary || '#0a84ff');
    }
  }, [content.brand?.colors?.primary]);

  const update = (next)=>{
    const newContent = typeof next==='function' ? next(content) : next;
    const merged = { ...content, ...newContent };
    setContent(merged);
    saveContent(merged);
  };

  const resetDefaults = ()=>{
    setContent(defaultContent);
    saveContent(defaultContent);
  };

  return { content, setContent: update, resetDefaults };
}
