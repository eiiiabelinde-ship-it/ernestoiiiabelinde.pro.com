
import Head from 'next/head';
import { useEffect, useState } from 'react';
import Nav from '../components/Nav';
import AdminPanel from '../components/AdminPanel';
import { useLiveContent } from '../hooks/useLiveContent';

export default function AdminRoute(){
  const { content, setContent } = useLiveContent();
  return (
    <>
      <Head><title>Admin • {content?.brand?.name || 'Elevate'}</title></Head>
      <Nav content={content} />
      <main className="pt-16 min-h-[60vh] flex items-center justify-center">
        <div className="text-center opacity-70">Admin overlay opened.</div>
      </main>
      <AdminPanel content={content} setContent={setContent} />
    </>
  );
}
