
import Head from 'next/head';
import { useEffect, useState } from 'react';
import Nav from '../components/Nav';
import AdminPanel from '../components/AdminPanel';
import ChatWidget from '../components/ChatWidget';

import { Hero, About, Services, Projects, ProjectPlan, Terms, ContactForm, Footer, News, Newsletter, Support } from '../Sections';
import { useLiveContent } from '../hooks/useLiveContent';

export default function Home(){
  const { content, setContent } = useLiveContent();
  const [isAdmin, setIsAdmin] = useState(false);
  const [threadId, setThreadId] = useState('');
  const [active, setActive] = useState('Home');

  // Admin gate + thread id for chat + hash routing
  useEffect(()=>{
    if (typeof window === 'undefined') return;
    const params = new URLSearchParams(window.location.search);
    const adminOn = params.get('admin') === '1';
    const pass = params.get('key') || '';
    const expected = content?.adminKey || 'changeme';
    if (adminOn && pass === expected) setIsAdmin(true);

    // visitor thread id for chat
    let t = params.get('thread') || localStorage.getItem('visitorId');
    if (!t){ t = 'visitor_' + Math.random().toString(36).slice(2); localStorage.setItem('visitorId', t); }
    setThreadId(t);

    const updateActive = ()=>{
      const hash = (window.location.hash || '#Home').slice(1) || 'Home';
      setActive(hash);
      window.scrollTo({ top: 0, behavior: 'smooth' });
      // reveal animation
      setTimeout(()=>{
        document.querySelectorAll('.reveal').forEach(el=> el.classList.add('visible'));
      }, 50);
    };
    updateActive();
    window.addEventListener('hashchange', updateActive);
    return ()=> window.removeEventListener('hashchange', updateActive);
  }, [content?.adminKey]);

  const renderSection = (id)=>{
    switch(id){
      case 'Home': return <Hero content={content} />;
      case 'About': return <About content={content} />;
      case 'Services': return <Services content={content} />;
      case 'Projects': return <Projects content={content} />;
      case 'Project-Plan':
      case 'ProjectPlan': return <ProjectPlan content={content} />;
      case 'News': return <News content={content} />;
      case 'Support': return <Support content={content} threadId={threadId} />;
      case 'Newsletter': return <Newsletter content={content} />;
      case 'Terms': return <Terms content={content} />;
      case 'Contact': return <ContactForm content={content} />;
      default: return <Hero content={content} />;
    }
  };

  const onlyId = active;

  return (
    <>
      <Head><title>{content?.brand?.name || 'Elevate'}</title></Head>
      <Nav content={content} />
      <main className="pt-16">
        {renderSection(onlyId)}
      </main>
      <Footer content={content} />
      {/* Floating chat for convenience on all pages */}
      <div className="fixed bottom-6 right-6 w-80">
        <div className="card p-2"><ChatWidget threadId={threadId} /></div>
      </div>
      {isAdmin && <AdminPanel content={content} setContent={setContent} />}
    </>
  );
}
