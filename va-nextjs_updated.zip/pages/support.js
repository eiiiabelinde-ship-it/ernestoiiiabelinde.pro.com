
import Head from 'next/head';
import { useEffect, useState } from 'react';
import Nav from '../components/Nav';
import ChatWidget from '../components/ChatWidget';
import { Footer, Support } from '../Sections';
import { useLiveContent } from '../hooks/useLiveContent';

export default function SupportPage(){
  const { content } = useLiveContent();
  const [threadId, setThreadId] = useState('');

  useEffect(()=>{
    if (typeof window==='undefined') return;
    let t = new URLSearchParams(window.location.search).get('thread') || localStorage.getItem('visitorId');
    if (!t){ t = 'visitor_' + Math.random().toString(36).slice(2); localStorage.setItem('visitorId', t); }
    setThreadId(t);
  }, []);

  return (
    <>
      <Head><title>Support • {content?.brand?.name || 'Elevate'}</title></Head>
      <Nav content={content} />
      <main className="pt-16">
        <Support content={content} threadId={threadId} />
      </main>
      <Footer content={content} />
    </>
  );
}
